#include "Consumption_announcement.h"


Date& Consumption_announcement::getDate(){
	return date;
}
int Consumption_announcement::get_EM_val(){
	return electricMeterVal;
}
