#include "Invoice.h"

double Invoice::get_toBePaid() const {return toBePaid;}