# MVM
A Programozás Alapjai 2. - NHF

### Controller.h
- Controller.h skeleton kész
  - Controller Destruktorra íródjanak ki a fájlok a txt-kbe
  - Controller Konstruktorral töltődjenek be a fájlok az Arrayeikbe.

### Sample adatok
- [] - A többi alap sample adatmező felvitele (Client: utolsó bejegyzett adat, egyenleg), többi fájl létrehozása 

### Osztálydiagram frissítése!